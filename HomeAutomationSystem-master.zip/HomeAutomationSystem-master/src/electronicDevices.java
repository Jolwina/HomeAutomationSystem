
public class electronicDevices {
	homeLights lights;
	tv Tele;
	airConditioner AC;
	audioSystem Audio;
	washingMachine WC;
	
	

}
